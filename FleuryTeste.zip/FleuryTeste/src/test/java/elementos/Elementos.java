package elementos;

import org.openqa.selenium.By;

public class Elementos {

	
	// clicar nas Unidades//
	public By cookies = By.cssSelector("body > div.cc-window.cc-banner.cc-type-info.cc-theme-classic.cc-bottom.cc-color-override--817642188 > div.cc-compliance > a");
	public By unidades = By.xpath("//body/div[@id='___gatsby']/div[@id='gatsby-focus-wrapper']/div[2]/div[1]/div[1]/div[1]/div[1]/div[16]/a[1]/div[1]");
	
	// Selecionar Proximo ao metro, Bicicletario e Unidades em Shoppings//
	public By selecionar = By.cssSelector("#checkoox-select-facilities > div");
	public By proxmetro = By.cssSelector("#gatsby-focus-wrapper > div.sc-bdVaJa.gridcomponent__GridStyled-sc-8zg10d-0.fHFDYJ > div.sc-bwzfXH.gridcomponent__RowStyled-sc-8zg10d-1.fqDNCQ > div:nth-child(3) > div.checkbox-selectcomponentstyle__CheckboxSelectWrapperStyled-sc-7ktrvg-0.ijWekg > div.animationcomponentstyle__ForcedFade-sc-7lsrx1-1.ebkWHA > div > div:nth-child(5) > svg.svg-inline--fa.fa-check-square.fa-w-14.checkbox-fieldcomponentstyle__CheckboxCheckedStyled-sc-1mdajsk-2.elhyct > path");
	public By bicicletario = By.cssSelector("#gatsby-focus-wrapper > div.sc-bdVaJa.gridcomponent__GridStyled-sc-8zg10d-0.fHFDYJ > div.sc-bwzfXH.gridcomponent__RowStyled-sc-8zg10d-1.fqDNCQ > div:nth-child(3) > div.checkbox-selectcomponentstyle__CheckboxSelectWrapperStyled-sc-7ktrvg-0.ijWekg > div.animationcomponentstyle__ForcedFade-sc-7lsrx1-1.ebkWHA > div > div:nth-child(6) > svg.svg-inline--fa.fa-check-square.fa-w-14.checkbox-fieldcomponentstyle__CheckboxCheckedStyled-sc-1mdajsk-2.elhyct > path");
	
	
	public By detalhes = By.cssSelector("#button-see-on-map-2-heitor-penteado > div");
	
	public By valunidade = By.cssSelector("#gatsby-focus-wrapper > div.sc-bdVaJa.gridcomponent__GridStyled-sc-8zg10d-0.fHFDYJ > div.sc-bwzfXH.gridcomponent__RowStyled-sc-8zg10d-1.efEBCe > div > h1");
}
