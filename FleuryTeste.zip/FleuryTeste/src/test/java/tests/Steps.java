package tests;

import elementos.Elementos;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.Metodos;

public class Steps {

	Metodos metodos = new Metodos();
	Elementos el = new Elementos();

	
	@Given("que eu esteja no site {string}")
	public void que_eu_esteja_no_site(String url) throws InterruptedException {
		metodos.abrirNavegador(url);
		metodos.pausa(3000);

	}

	@When("clicar nas unidades")
	public void clicar_nas_unidades() {
		metodos.clicar(el.cookies);
		metodos.esperaImplicita();
		metodos.clicar(el.unidades);
	}

	@When("escolher opcoes de facilidade")
	public void escolher_opcoes_de_facilidade() throws InterruptedException {
		metodos.clicar(el.selecionar);
		metodos.clicar(el.proxmetro);
		metodos.clicar(el.bicicletario);
		metodos.pausa(3000);

	}

	@When("selecionar primeira unidade")
	public void selecionar_primeira_unidade() {
		metodos.clicar(el.detalhes);
	}

	@Then("validar Nome da unidade")
	public void validar_nome_da_unidade() throws InterruptedException {
		metodos.pausa(3000);
		metodos.validarTexto(el.valunidade, "Heitor Penteado");
		metodos.fecharNavegador();
	}

}
